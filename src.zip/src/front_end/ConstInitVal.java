package front_end;

public class ConstInitVal {
}
